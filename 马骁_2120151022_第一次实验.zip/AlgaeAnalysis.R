#数据挖掘第一次作业
#载入数据
algae<-read.table('Analysis.txt',header=F,dec='.',col.names=c('season','size','speed','mxPH','mn02','C1','NO3','NH4','oPO4','PO4','Chla','a1','a2','a3','a4','a5','a6','a7'),na.strings=c('XXXXXXX'))
#展示数据前六行
head(algae)
#数据摘要
summary(algae)
#数据可视化
#绘制直方图
hist(seaweed$mxPH)
hist(seaweed$mmO2)
hist(seaweed$Cl)
hist(seaweed$NO3)
hist(seaweed$NH4)
hist(seaweed$oPO4)
hist(seaweed$PO4)
hist(seaweed$Chla)
#绘制数值属性的qq图
install.packages("car")
library(car)
qqPlot(algae$mxPH,main='Normal QQ plot of mxPH')
qqPlot(algae$mmO2,main='Normal QQ plot of mmO2')
qqPlot(algae$Cl,main='Normal QQ plot of Cl')
qqPlot(algae$NO3,main='Normal QQ plot of NO3')
qqPlot(algae$NH4,main='Normal QQ plot of NH4')
qqPlot(algae$ oPO4,main='Normal QQ plot of oPO4')
qqPlot(algae$ PO4,main='Normal QQ plot of PO4')
qqPlot(algae$Chla,main='Normal QQ plot of Chla')
#绘制数值属性的盒图
boxplot(algae$mxPH,ylab="mxPH")
rug(algae$mxPH,side=4)
abline(h=mean(algae$mxPH,na.rm=T),lty=2)
boxplot(algae$mmO2,ylab="mmO2")
rug(algae$mmO2,side=4)
abline(h=mean(algae$mmO2,na.rm=T),lty=2)
boxplot(algae$Cl,ylab="Cl")
rug(algae$Cl,side=4)
abline(h=mean(algae$Cl,na.rm=T),lty=2)
boxplot(algae$NO3,ylab="NO3")
rug(algae$NO3,side=4)
abline(h=mean(algae$NO3,na.rm=T),lty=2)
boxplot(algae$NH4,ylab="NH4")
rug(algae$NH4,side=4)
abline(h=mean(algae$NH4,na.rm=T),lty=2)
boxplot(algae$oPO4,ylab="oPO4")
rug(algae$oPO4,side=4)
abline(h=mean(algae$oPO4,na.rm=T),lty=2)
boxplot(algae$PO4,ylab="PO4")
rug(algae$PO4,side=4)
abline(h=mean(algae$PO4,na.rm=T),lty=2)
boxplot(algae$Chla,ylab="Chla")
rug(algae$Chla,side=4)
abline(h=mean(algae$Chla,na.rm=T),lty=2)
#对每一种海藻绘制数量和标称变量的盒图
install.packages("DAAG")
library(DAAG)
bwplot(size~a1,data=algae,ylab="River Size",xlab="Algal a1")
bwplot(season~a1,data=algae,ylab="Season",xlab="Algal a1")
bwplot(speed~a1,data=algae,ylab="Speed",xlab="Algal a1")
bwplot(size~a2,data=algae,ylab="River Size",xlab="Algal a2")
bwplot(season~a2,data=algae,ylab="Season",xlab="Algal a2")
bwplot(speed~a2,data=algae,ylab="Speed",xlab="Algal a2")
bwplot(size~a3,data=algae,ylab="River Size",xlab="Algal a3")
bwplot(season~a3,data=algae,ylab="Season",xlab="Algal a3")
bwplot(speed~a3,data=algae,ylab="Speed",xlab="Algal a3")
bwplot(size~a4,data=algae,ylab="River Size",xlab="Algal a4")
bwplot(season~a4,data=algae,ylab="Season",xlab="Algal a4")
bwplot(speed~a4,data=algae,ylab="Speed",xlab="Algal a4")
bwplot(size~a5,data=algae,ylab="River Size",xlab="Algal a5")
bwplot(season~a5,data=algae,ylab="Season",xlab="Algal a5")
bwplot(speed~a5,data=algae,ylab="Speed",xlab="Algal a5")
bwplot(size~a6,data=algae,ylab="River Size",xlab="Algal a6")
bwplot(season~a6,data=algae,ylab="Season",xlab="Algal a6")
bwplot(speed~a6,data=algae,ylab="Speed",xlab="Algal a6")
bwplot(size~a7,data=algae,ylab="River Size",xlab="Algal a7")
bwplot(season~a7,data=algae,ylab="Season",xlab="Algal a7")
bwplot(speed~a7,data=algae,ylab="Speed",xlab="Algal a7")
#数据缺失的处理
#将含有缺失值的记录剔除
#首先检查含有缺失值的记录
#重新读取文件
algae<-read.table('Analysis.txt',col.name=c('season','size','speed','mxPH','mmO2','Cl','NO3','NH4','oPO4','PO4','Chla','a1','a2','a3','a4','a5','a6','a7'),na.strings=c('XXXXXXX'))
algae[!complete.cases(algae),]
#剔除含有缺失值的记录
algae<-na.omit(algae)
#将结果保存在1.txt里面
write.table (algae, file ="C:/Users/marsh/OneDrive/个人/学习/2015-2016第二学期/数据挖掘/第一次作业/1.txt",row.names =F, col.names =F, quote =TRUE)
#用最高频率值来填补缺失值
#重新读取文件
algae<-read.table('Analysis.txt',col.name=c('season','size','speed','mxPH','mmO2','Cl','NO3','NH4','oPO4','PO4','Chla','a1','a2','a3','a4','a5','a6','a7'),na.strings=c('XXXXXXX'))
install.packages("DMwR")
library(DMwR)
data(algae)
algae<-algae[-manyNAs(algae),]
algae<-centrallmputation(algae)
#将结果保存在2.txt里面
write.table (algae, file ="C:/Users/marsh/OneDrive/个人/学习/2015-2016第二学期/数据挖掘/第一次作业/2.txt",row.names =F, col.names =F, quote =TRUE)
#通过属性相关关系填补缺失值
#重新读取文件
algae<-read.table('Analysis.txt',col.name=c('season','size','speed','mxPH','mmO2','Cl','NO3','NH4','oPO4','PO4','Chla','a1','a2','a3','a4','a5','a6','a7'),na.strings=c('XXXXXXX'))
#获取属性之间的相关矩阵
data(algae)
symnum(cor(algae[,4:18],use="complete.obs"))
#剔除样本62和样本199
algae=algae[-62,]
algae=algae[-198,]
#寻找PO4和oPO4之间的线性关系
algae<-algae[-manyNAs(algae),]
lm(formula=PO4~oPO4,data=algae)
#用线性关系填补缺失值
algae[28,"PO4"]<-42.897+1.293*algae[28,"oPO4"]
#将结果保存在3.txt里面
write.table (algae, file ="C:/Users/marsh/OneDrive/个人/学习/2015-2016第二学期/数据挖掘/第一次作业/3.txt",row.names =F, col.names =F, quote =TRUE)
#通过数据对象之间的相似性来填补缺失值
#重新读取文件
algae<-read.table('Analysis.txt',col.name=c('season','size','speed','mxPH','mmO2','Cl','NO3','NH4','oPO4','PO4','Chla','a1','a2','a3','a4','a5','a6','a7'),na.strings=c('XXXXXXX'))
#用数据对象之间的相似性填补
algae<-knnImputation(algae,k=10)
#保存结果在4.txt里面
write.table (algae, file ="C:/Users/marsh/OneDrive/个人/学习/2015-2016第二学期/数据挖掘/第一次作业/4.txt",row.names =F, col.names =F, quote =TRUE)